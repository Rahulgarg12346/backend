
const { v4: uuidv4 } = require('uuid');
const Student = require('../Module/Studentmodel');
const cloudinary = require('cloudinary').v2;
const multer = require('multer');

const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Configure Cloudinary
cloudinary.config({
    cloud_name: 'djrh8oflc',
    api_key: '544113442678141',
    api_secret: 'G6AKEYGFz2eiEcVHXg-4myu5cXg'
});

// Set up multer for image uploading
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'upload'); // This will not be used when using Cloudinary
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname); // This will not be used when using Cloudinary
  }
});

const upload = multer({ storage: storage }).single('StudentPhoto');

exports.register = async (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      console.error(err);
      return res.status(500).send('Server Error');
    }
    try {
      const {
        StudentName,
        FatherName,
        MotherName,
        Emailid,
        Gender,
        DOB,
        ClassName,
        BoardName,
        Address,
        State,
        FatherNumber,
        MotherNumber,
        Password,
        CityName,
        token = uuidv4()
      } = req.body;

      // Upload image to Cloudinary
      const result = await cloudinary.uploader.upload(req.file.path);

      const model = await Student.create({
        StudentName,
        FatherName,
        MotherName,
        Emailid,
        Gender,
        DOB,
        ClassName,
        BoardName,
        Address,
        State,
        FatherNumber,
        MotherNumber,
        Password,
        CityName,
        token,
        StudentPhoto: result.secure_url // Use the Cloudinary URL for StudentPhoto
      });

      res.status(201).json(model);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });
};



exports.login = async (req, res) => {
  try {
    const { Emailid, Password } = req.body;

    // Find the user by email
    const user = await Student.findOne({ Emailid });

    // Check if user and password match
    if (user && bcrypt.compare(Password, user.Password)) {
      // Passwords match, user is authenticated
      res.status(200).json({ message: "Login successful", user });
    } else {  
      // Incorrect email or password
      res.status(401).json({ error: "Unauthorized" });
    }
  } catch (error) {
    console.error("Error in login route:", error);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
};




exports.getStudentByclassestoken = async (req, res) => {
  const { classestoken } = req.params;

  try {
    if (!classestoken) {
      return res.status(400).json({ error: "Classestoken is required" });
    }
    
    const student = await Student.find({ Classestoken: classestoken });
    
    if (!student) {
      return res.status(404).json({ error: "Student not found" });
    }
  
    res.status(200).json(student);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getStudentByToken = async (req, res) => {
  const { token } = req.params;

  try {
      if (!token) {
          return res.status(400).json({ error: "Token is required" });
      }
      
      const student = await Student.find({ token: token });
      
      if (!student) {
          return res.status(404).json({ error: "Student not found" });
      }
      
      res.status(200).json(student);
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};

exports.getAllStudent = async (req, res) => {
  try {
      const students = await Student.find();
      res.status(200).json(students);
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};

exports.updateStudent = async (req, res) => {
  try {
    const { token } = req.params;
    let updateFields = req.body;

    // Check if image file is uploaded
    if (req.file) {
      // If image is uploaded, update the image field in updateFields
      updateFields = {
        ...updateFields,
        StudentPhoto: req.file.path // Assuming StudentPhoto is the field to store the image path
      };
    }

    const updatedStudent = await Student.findOneAndUpdate({ token: token }, updateFields, { new: true });

    if (!updatedStudent) {
      return res.status(404).json({ error: "Student not found" });
    }

    res.status(200).json(updatedStudent);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.deleteStudent = async (req, res) => {
  try {
      const { token } = req.params;
      const deletedStudent = await Student.findOneAndDelete({ token: token });
      
      if (!deletedStudent) {
          return res.status(404).json({ error: "Student not found" });
      }

      res.status(200).json({ message: "Student deleted successfully" });
  } catch (error) {
      res.status(500).json({ error: error.message });
  }
};