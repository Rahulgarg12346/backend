    const Student = require('../Module/FeesDueModule');
    const uuid = require('uuid');


    // Create a new student
    exports.createStudent = async (req, res) => {
        try {
            const token = uuid.v4(); // Generate a unique token
            const student = new Student({
                StudentToken: req.body.StudentToken,
                name: req.body.name,
                className: req.body.className, // Adjusted from req.body.class to match your body structure
                totalFees: req.body.totalFees,
                feesPaid: req.body.feesPaid,
                token: token
            });
            await student.save();
            res.status(201).json(student);
        } catch (err) {
            res.status(400).json({ message: err.message });
        }
    };






    // Get all students
    exports.getAllStudents = async (req, res) => {
        try {
            const students = await Student.find();
            res.json(students);
        } catch (err) {
            res.status(500).json({ message: err.message });
        }
    };

    // Get a particular student by token
    exports.getStudentByToken = async (req, res) => {
        try {
            const student = await Student.findOne({ StudentToken: req.params.token });
            if (!student) {
                return res.status(404).json({ message: 'Student not found' });
            }
            const feesDue = student.totalFees - student.feesPaid;
            // Include the student data along with the calculated feesDue in the response
            const studentWithFeesDue = { ...student.toObject(), feesDue: feesDue };
            res.json(studentWithFeesDue);
        } catch (err) {
            return res.status(500).json({ message: err.message });
        }
    };

    // Update a student's details
    exports.updateStudent = async (req, res) => {
        try {
            const student = await Student.findOneAndUpdate({ token: req.params.token }, req.body, { new: true });
            if (!student) {
                return res.status(404).json({ message: 'Student not found' });
            }
            res.json(student);
        } catch (err) {
            return res.status(500).json({ message: err.message });
        }
    };

    // Delete a student
    exports.deleteStudent = async (req, res) => {
        try {
            const student = await Student.findOneAndDelete({ token: req.params.token });
            if (!student) {
                return res.status(404).json({ message: 'Student not found' });
            }
            res.json({ message: 'Student deleted successfully' });
        } catch (err) {
            return res.status(500).json({ message: err.message });
        }
    };

    // Calculate due fees for a particular student by token
    exports.calculateFeesDue = async (req, res) => {
        try {
            const student = await Student.findOne({ token: req.params.token });
            if (!student) {
                return res.status(404).json({ message: 'Student not found' });
            }
            const feesDue = student.totalFees - student.feesPaid;
            // Include the student data along with the calculated feesDue in the response
            const studentWithFeesDue = { ...student.toJSON(), feesDue: feesDue };
            res.json(studentWithFeesDue);
        } catch (err) {
            return res.status(500).json({ message: err.message });
        }
    };

    // exports.calculateFeesDue = async (req, res) => {
    //     try {
    //         const student = await Student.findOne({ token: req.params.token });
    //         if (!student) {
    //             return res.status(404).json({ message: 'Student not found' });
    //         }
    //         const feesDue = student.totalFees - student.feesPaid;
    //         res.json({ feesDue: feesDue });
    //     } catch (err) {
    //         return res.status(500).json({ message: err.message });
    //     }
    // };