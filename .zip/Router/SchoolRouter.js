// const express = require('express')

// const controller = require('../Controller/SchoolController');

// const router = express.Router();

// router.post('/signup', controller.signup);
// router.post('/login', controller.login);


// router.post('/Teacher', controller.createItem);
// router.get('/Teacher/:id', controller.getAllItemById);
// router.delete('/Teacher/:id', controller.deleterItem);
// router.put('/Teacher/:id', controller.updateItem);



// router.post('/student', controller.register);
// router.post('/student', controller.createItem);
// router.get('/student/:id', controller.getAllItemById);
// router.delete('/student/:id', controller.deleterItem);
// router.put('/student/:id', controller.updateItem);



// module.exports=router;
