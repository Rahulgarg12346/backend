const express = require('express');
const router = express.Router();
const studentController = require('../Controller/FeesDueController')

// Create a new student
router.post('/students', studentController.createStudent);

// Get all students
router.get('/students', studentController.getAllStudents);

// Get a particular student by token
router.get('/students/:token', studentController.getStudentByToken);

// Update a student's details
router.put('/students/:token', studentController.updateStudent);

// Delete a student
router.delete('/students/:token', studentController.deleteStudent);

// Calculate due fees for a particular student by token
router.get('/students/:token/fees-due', studentController.calculateFeesDue);

module.exports = router;