const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
    StudentToken:{
        type:String,
        require:true
    },
    name: {
        type: String,
        required: true
    },
    className: {
        type: String,
        required: true
    },
    totalFees: {
        type: Number,
        required: true
    },
    feesPaid: {
        type: Number,
        required: true
    },
    token: {
        type: String,
     
    }
});

const Student = mongoose.model('Student', studentSchema);

module.exports = Student;   