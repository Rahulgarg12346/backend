const mongoose = require('mongoose');

const studentGradeSchema = new mongoose.Schema({
  studenttoken: { type: String, required: true },
  Classestoken: { type: String, required: true },
  Student_name: { type: String, required: true },
  studentClass: { type: String, required: true },
  grades: {
    english: { type: Number, required: true },
    hindi: { type: Number, required: true },
    math: { type: Number, required: true },
    science: { type: Number, required: true },
    social_science: { type: Number, required: true },
    sanskrit: { type: Number, required: true }
  },
  token: { type: String, required: true }
});

module.exports = mongoose.model('StudentGrade', studentGradeSchema);
