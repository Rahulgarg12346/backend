
const mongoose = require('mongoose');

const imageSchema = new mongoose.Schema({
  img: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },

 
});

const Image = mongoose.model('Image', imageSchema);

module.exports = Image;